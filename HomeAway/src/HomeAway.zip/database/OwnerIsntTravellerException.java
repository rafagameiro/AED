/**
 * 
 */
package database;

/**
 * @author thinkpad
 *
 */
public class OwnerIsntTravellerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public OwnerIsntTravellerException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public OwnerIsntTravellerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
