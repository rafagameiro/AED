/**
 * 
 */
package database;

/**
 * @author Rafael Gameiro (50677) rr.gameiro@campus.fct.unl.pt
 * @author Rui Santos (50833) rfc.santos@campus.fct.unl.pt
 *
 */
public class BothTravellerAndOwnerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public BothTravellerAndOwnerException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public BothTravellerAndOwnerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
